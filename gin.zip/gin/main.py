import numpy as np
from scipy import special, stats
from gin.intermediate._dg1 import dgin1 as dgin1
from gin.intermediate._rtg1 import rtgin1 as rtgin1
from gin.intermediate._F0g import F0gin as F0gin
from gin.intermediate._pbd import pbdam as pbdam

# General density with tau from (0, infinity)
def dgin(z, a, m, t, log=True, quasi=False):
    if (t <= 0):
        res = -np.inf
    else:
        mt = m / t
        if quasi:
            res = dgin1(z * t, a, mt, True, True) + a * np.log(t)
        else:
            res = dgin1(z * t, a, mt, True, False) + np.log(t)
    if log:
        return res
    else:
        return np.exp(res)

def dtgin(z, a, m, t, sign=True, log=True, quasi=False):
    # Sign = True, means truncate to z > 0; Sign = False is to z < 0
    if (sign):
        t_z = (z <= 0)
        mult = -1
    else:
        t_z = (z >= 0)
        mult = 1

    # Impose restrictions and compute density
    if t_z | (a <= 1) | (t <= 0):
        res = -np.inf
    else:
        mt = m / t
        lkern = dgin1(z * t, a, mt, True, True) + np.log(t)
        if quasi:
            res = lkern
        else:
            lcons = -0.25 * mt ** 2 + special.loggamma(a - 1) + np.log(pbdam(a, mult * mt))
            res = lkern - lcons
    if log:
        return res
    else:
        return np.exp(res)

def rtgin(size, a, m, t, sign, algo=True, verbose=False):
    # If sign = True, draw from the positive region Z > 0
    # If sign = False, draw from the negative region Z < 0

    # If algo = True, use the Minimal Bounding Rectangle from Hörmann and Leydold (2014),
    # if algo = False, use the one from Leydold (2001)
    res = np.zeros(size)
    if verbose: ARiters = np.copy(res)
    mt = m / t
    for i in range(size):
        temp = rtgin1(a, mt, sign, algo, verbose)
        if verbose:
            res[i] = temp['value'] / t
            ARiters[i] = temp['ARiters']
        else:
            res[i] = temp / t
    if verbose:
        return {'value': res, 'avg_arate': np.mean(1 / ARiters), 'ARiters': ARiters}
    else:
        return res


# Generator of generalized inverse normal variables
def rgin(size, a, m, t, sign=True, algo=True):
    # If sign is true, more samples are expected from the positive region (e.g., mu > 0),
    # i.e., P(>0) >= 50%. Probability calculation of that region is more stable
    # If sign is negative, you expect P(<0) >= 50% (e.g., mu < 0) and that region's probability is used

    # If algo = True, use the Minimal Bounding Rectangle from Hörmann and Leydold (2014),
    # if algo = False, use the one from Leydold (2001)

    F0r = F0gin(a, m, t, sign)
    res = np.zeros(size)
    side = (stats.uniform.rvs(size=size) <= F0r)
    sum_side = sum(side)
    res[side == 0] = rtgin(size - sum_side, a, m, t, not sign, algo)
    res[side == 1] = rtgin(sum_side, a, m, t, sign, algo)
    return res
