# Generalized Inverse Normal (GIN) distribution

Density and generation from the generalized inverse normal distribution from Robert (1991).