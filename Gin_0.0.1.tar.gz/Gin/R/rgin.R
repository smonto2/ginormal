#' Title
#'
#' @param size
#' @param a
#' @param m
#' @param t
#' @param algo
#'
#' @return rgin
#' @export rgin
#'
#' @examples
rgin <- function(size, a, m, t, algo=TRUE){
  sign = (m >= 0)
  F0r = F0gin(a, m, t, sign)
  res = rep(0,size)
  side = (runif(size) <= F0r)
  sum_side = sum(side)
  #if (side)
  res[side == 0] = rtgin(size - sum_side, a, m, t, -sign, algo)
  res[side == 1] = rtgin(sum_side, a, m, t, sign, algo)
  return(res)
}
