library(BAS)
# General density with tau from (0, infinity)
#' Title
#'
#' @param z 1
#' @param a 1
#' @param m 1
#' @param t 1
#' @param log 1
#' @param quasi 1
#'
#' @return 1
#' @export dgin
#'
#' @examples

dgin <- function(z, a, m, t, log=TRUE, quasi=FALSE){
  if (t<=0){
    res <- -Inf
  }else{
    mt <- m / t
    if (quasi==TRUE){
      res = dgin1(z * t, a, mt, TRUE, TRUE) + a * log(t)
    }else{
      res = dgin1(z * t, a, mt, TRUE, FALSE) + log(t)
    }
  }

  if (log==TRUE){
    return(res)
  }else{
    return(exp(res))
  }
}
