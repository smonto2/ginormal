#' Title
#'
#' @param z
#' @param a
#' @param m
#' @param t
#' @param sign
#' @param log
#' @param quasi
#'
#' @return dtgin
#' @export dtgin
#'
#' @examples
dtgin <- function(z, a, m, t, sign=TRUE, log=TRUE, quasi=FALSE){
  if (sign==0){
    t_z = (z <= 0)
    mult = -1
  }else{
    t_z = (z >= 0)
    mult = 1
  }

  if(t_z == TRUE | (a <= 1) | (t <= 0)){
    res = Inf
  }else{
    mt = m / t
    lkern = dgin1(z * t, a, mt, TRUE, TRUE) + log(t)
    if (quasi==TRUE){
      res = lkern
    }else{
      lcons = -0.25 * mt ** 2 + log(gamma(a - 1)) + log(pbdam(a, mult * mt))
      res = lkern - lcons
    }
  }

  if (log==TRUE){
    return(res)
  }else{
    return(exp(res))
  }
}
