# CDF of generalized inverse normal at 0
#' Internal function
#'
#' This is an internal function that adds two numbers.
#'
#' @param a  a degrees-of-freedom parameter
#' @param b A single numeric value.
#' @return F0gin
F0gin <- function(a, m, t, sign=TRUE){
  mult = 1 - 2 * sign
  mt = m / t
  parhyp = log(pbdam(a, mult * mt)) - hypergeometric1F1(0.5 * (a - 1), 0.5, 0.5*mt^2, log = TRUE)
  lcons = 0.25 * (mt ^ 2) + 0.5 * (a - 3) * log(2) - 0.5 * log(pi) + lgamma(0.5 * a) + parhyp
  return(exp(lcons))
}
