#' Title
#'
#' @param size
#' @param a
#' @param m
#' @param t
#' @param sign
#' @param algo
#' @param verbose
#'
#' @return rtgin
#' @export rtgin
#'
#' @examples
rtgin <- function(size, a, m, t, sign=TRUE, algo=TRUE, verbose=FALSE) {
  res <- rep(0, size)
  if (verbose) {
    ARiters <- rep(0, size)
  }
  mt <- m / t
  for (i in 1:size) {
    temp <- rtgin1(a, mt, sign, algo, verbose)
    if (verbose) {
      res[i] <- temp$value / t
      ARiters[i] <- temp$ARiters
    } else {
      res[i] <- temp / t
    }
  }
  if (verbose) {
    return(list(value=res, avg_arate=mean(1/ARiters), ARiters=ARiters))
  } else {
    return(res)
  }
}
